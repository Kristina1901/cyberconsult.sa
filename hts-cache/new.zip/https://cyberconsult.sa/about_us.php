<!DOCTYPE html>
<html lang="en" class="no-js">
<!-- Begin Head -->
<head>

    <!-- Basic -->
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>cyberconsult.sa - A Digital Security Consultant in Communication and Information Technology</title>
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <meta name="author" content="Reza Yogaswara"/>
    <meta name="website" content="https://me.rezayogaswara.com"/>
    <meta name="version" content="1.0.0"/>
    <meta
            name="description"
            content="A Digital Security Consultant in Communication and Information Technology"
    />
    <meta name="keywords" content="cyberconsult.sa, A Digital Security Consultant in Communication and Information Technology"/>

    <!-- Web Fonts -->
    <!--<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i|Montserrat:400,700" rel="stylesheet">-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@200;300;400;500&display=swap" rel="stylesheet">

    <!-- Vendor Styles -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="css/animate.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/themify/themify.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/scrollbar/scrollbar.min.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/swiper/swiper.min.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet" type="text/css"/>

    <!-- Theme Styles -->
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
    <link href="css/global/global.css" rel="stylesheet" type="text/css"/>
</head>
<!-- End Head -->

<!-- Body -->
<body>

<!--========== HEADER ==========-->
<header class="navbar-fixed-top s-header js__header-sticky js__header-overlay">
    <!-- Navbar -->
    <div class="s-header__navbar">
        <div class="s-header__container">
            <div class="s-header__navbar-row">
                <div class="s-header__navbar-row-col">
                    <!-- Logo -->
                    <div class="s-header__logo">
                        <a href="https://cyberconsult.sa/" class="s-header__logo-link">
                            <!--
                            <img class="s-header__logo-img s-header__logo-img-default" src="img/logo.png" alt="cyberconsult.sa">
                            <img class="s-header__logo-img s-header__logo-img-shrink" src="img/logo-dark.png" alt="cyberconsult.sa">
                            -->
                            <img class="s-header__logo-img s-header__logo-img-default"
                                 src="https://cyberconsult.sa/logo/Cyber Consult small 2.png" alt="cyberconsult.sa">
                            <img class="s-header__logo-img s-header__logo-img-shrink"
                                 src="https://cyberconsult.sa/logo/Cyber Consult small 2.png" alt="cyberconsult.sa">
                        </a>
                    </div>
                    <!-- End Logo -->
                </div>
                <div class="s-header__navbar-row-col">
                    <!-- Trigger -->
                    <a href="javascript:void(0);" class="s-header__trigger js__trigger">
                        <span class="s-header__trigger-icon"></span>
                        <svg x="0rem" y="0rem" width="3.125rem" height="3.125rem" viewbox="0 0 54 54">
                            <circle fill="transparent" stroke="#fff" stroke-width="1" cx="27" cy="27" r="25"
                                    stroke-dasharray="157 157" stroke-dashoffset="157"></circle>
                        </svg>
                    </a>
                    <!-- End Trigger -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Navbar -->

    <!-- Overlay -->
    <div class="s-header-bg-overlay js__bg-overlay">
        <!-- Nav -->
        <nav class="s-header__nav js__scrollbar">
            <div class="container-fluid">
                <!-- Menu List -->
                <!--
                <ul class="list-unstyled s-header__nav-menu">
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider -is-active" href="index.html">Corporate</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_app_landing.html">App Landing</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_portfolio.html">Portfolio</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_events.html">Events</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_lawyer.html">Lawyer</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_clinic.html">Clinic</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_coming_soon.html">Coming Soon</a></li>
                </ul>
                -->
                <!-- End Menu List -->

                <!-- Menu List -->
                <ul class="list-unstyled s-header__nav-menu">
                    <li class="s-header__nav-menu-item"><a
                                class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="https://cyberconsult.sa/">Home</a></li>
                    <li class="s-header__nav-menu-item"><a
                                class="s-header__nav-menu-link s-header__nav-menu-link-divider -is-active" href="https://cyberconsult.sa/about_us.php">About
                            Us</a></li>
                    <li class="s-header__nav-menu-item"><a
                                class="s-header__nav-menu-link s-header__nav-menu-link-divider"
                                href="https://cyberconsult.sa/team.php">Team</a></li>
                    <li class="s-header__nav-menu-item"><a
                                class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="https://cyberconsult.sa/our_services.php">Our
                            Services</a></li>
                    <!--<li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="events.html">Events</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="faq.html">FAQ</a></li>-->
                    <li class="s-header__nav-menu-item"><a
                                class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="https://cyberconsult.sa/contact_us.php">Contact Us</a>
                    </li>
                </ul>
                <!-- End Menu List -->
            </div>
        </nav>
        <!-- End Nav -->

        <!-- Action -->
        <!--
        <ul class="list-inline s-header__action s-header__action--lb">
            <li class="s-header__action-item"><a
                        class="s-header__action-link  "
                        href="https://cyberconsult.sa/change_language.php?s=42f5a3a0ff2feb5896eef5a9e82f059c2b4030749878fdcd30ad84d5afbaba4a0e83478552a6c16549204d37dcd48217c90caff1159466f93b53348442a33823&l=aa85f1840e282d8a8304dbc2c0d7c9b2&p=amxVb1ZxRXc0QTFrdk9hWWV5WE5Mdz09">En</a>
            </li>
            <li class="s-header__action-item"><a
                        class="s-header__action-link "
                        href="https://cyberconsult.sa/change_language.php?s=42f5a3a0ff2feb5896eef5a9e82f059c2b4030749878fdcd30ad84d5afbaba4a0e83478552a6c16549204d37dcd48217c90caff1159466f93b53348442a33823&l=3dd6b9265ff18f31dc30df59304b0ca7&p=amxVb1ZxRXc0QTFrdk9hWWV5WE5Mdz09">Ar</a>
            </li>
        </ul>
        -->
        <!-- End Action -->

        <!-- Action -->
        <!--
        <ul class="list-inline s-header__action s-header__action--rb">
            <li class="s-header__action-item">
                <a class="s-header__action-link" href="#">
                    <i class="g-padding-r-5--xs ti-twitter"></i>
                    <span class="g-display-none--xs g-display-inline-block--sm">Twitter</span>
                </a>
            </li>
            <li class="s-header__action-item">
                <a class="s-header__action-link" href="#">
                    <i class="g-padding-r-5--xs ti-facebook"></i>
                    <span class="g-display-none--xs g-display-inline-block--sm">Facebook</span>
                </a>
            </li>
            <li class="s-header__action-item">
                <a class="s-header__action-link" href="#">
                    <i class="g-padding-r-5--xs ti-instagram"></i>
                    <span class="g-display-none--xs g-display-inline-block--sm">Instagram</span>
                </a>
            </li>
        </ul>
        -->
        <!-- End Action -->
    </div>
    <!-- End Overlay -->
</header>
<!--========== END HEADER ==========-->

<!--========== PROMO BLOCK ==========-->
<!--
<div class="g-fullheight--md js__parallax-window" style="background: url(img/1920x1080/02.jpg) 50% 0 no-repeat fixed;">
    <div class="g-container--md g-text-center--xs g-ver-center--md g-padding-y-150--xs g-padding-y-0--md">
        <div class="g-margin-b-60--xs">
            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--white-opacity g-letter-spacing--2 g-margin-b-25--xs">Welcome to Megakit</p>
            <h1 class="g-font-size-40--xs g-font-size-50--sm g-font-size-60--md g-color--white g-letter-spacing--1">Creative Design</h1>
            <p class="g-font-size-18--xs g-font-size-26--md g-color--white-opacity g-margin-b-0--xs">We are a creative studio focusing on culture, luxury, editorial &amp; art. Somewhere between sophistication and simplicity.</p>
        </div>
        <span class="g-display-block--xs g-display-inline-block--sm g-padding-x-5--xs g-margin-b-10--xs g-margin-b-0--sm">
            <a href="https://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" class="text-uppercase s-btn s-btn-icon--md s-btn--primary-bg g-radius--50 g-padding-x-45--xs">Learn More</a>
        </span>
        <span class="g-display-block--xs g-display-inline-block--sm g-padding-x-5--xs g-margin-b-10--xs g-margin-b-0--sm">
            <a href="https://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" class="text-uppercase s-btn s-btn-icon--md s-btn--white-brd g-radius--50 g-padding-x-65--xs">Contact Us</a>
        </span>
    </div>
</div>
-->
<!--========== END PROMO BLOCK ==========-->

<!--========== PAGE CONTENT ==========-->
<!-- About -->
<div class="container g-padding-y-80--xs g-padding-y-125--sm">
    <div class="row g-hor-centered-row--md g-row-col--5 g-margin-b-60--xs g-margin-b-100--md">
        <div class="col-sm-3 col-xs-6 g-hor-centered-row__col">
            <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".1s">
                <img class="img-responsive" src="img/raw/cyber_security_layer.jpeg" alt="Image">
            </div>
        </div>
        <!--
        <div class="col-sm-3 col-xs-6 g-hor-centered-row__col g-margin-b-60--xs g-margin-b-0--md">
            <div class="wow fadeInLeft" data-wow-duration=".3" data-wow-delay=".2s">
                <img class="img-responsive" src="img/400x550/01.jpg" alt="Image">
            </div>
        </div>
        -->
        <div class="col-sm-1"></div>
        <div class="col-sm-8 g-hor-centered-row__col">
            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-25--xs">
                About</p>
            <h2 class="g-font-size-32--xs g-font-size-36--sm g-margin-b-25--xs">Cyber Consult</h2>
            <p class="g-font-size-18--sm">We have a team of experienced and seasoned cyber consultants to offer a straightforward and affordable review of your current situation. We will analyze the current situation of your cyber security standards and spot the potential risks in your systems. Here at Cyber Consult, we provide consultancy expertise and affordable offerings for companies and organizations interested in accessing and auditing cyber risk. We work with an international client base to ensure our customers benefit from the highest quality solutions, as well as pragmatic suggestions to mitigate cyber risk in an effective matter. </p>
        </div>
    </div>

    <!--
    <div class="row g-hor-centered-row--md g-row-col--5">
        <div class="col-sm-3 col-xs-6 col-sm-push-6 g-hor-centered-row__col">
            <div class="wow fadeInRight" data-wow-duration=".3" data-wow-delay=".2s">
                <img class="img-responsive" src="img/400x550/02.jpg" alt="Image">
            </div>
        </div>
        <div class="col-sm-3 col-xs-6 col-sm-push-6 g-hor-centered-row__col g-margin-b-60--xs g-margin-b-0--md">
            <div class="wow fadeInRight" data-wow-duration=".3" data-wow-delay=".1s">
                <img class="img-responsive" src="img/400x500/06.jpg" alt="Image">
            </div>
        </div>
        <div class="col-sm-1"></div>
        <div class="col-sm-5 col-sm-pull-7 g-hor-centered-row__col g-text-left--xs g-text-right--md">
            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-25--xs">Speakers</p>
            <h2 class="g-font-size-32--xs g-font-size-36--sm g-margin-b-25--xs">Keynote Speakers</h2>
            <p class="g-font-size-18--sm">Working together on the daily requires each individual to let the greater good of the team’s work surface above their own ego.</p>
        </div>
    </div>
    -->
</div>
<!-- End About -->

<!-- Process -->
<!--
<div class="g-bg-color--primary-ltr">
    <div class="container g-padding-y-80--xs g-padding-y-125--sm">
        <div class="g-text-center--xs g-margin-b-100--xs">
            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--white-opacity g-letter-spacing--2 g-margin-b-25--xs">
                Process</p>
            <h2 class="g-font-size-32--xs g-font-size-36--md g-color--white">How it Works</h2>
        </div>
        <ul class="list-inline row g-margin-b-100--xs">

            <li class="col-sm-3 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--md">
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">01</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-color--white">Consult</h3>
                        <p class="g-color--white-opacity">This is where we sit down, grab a cup of coffee and dial in
                            the details.</p>
                    </div>
                </div>
            </li>

            <li class="col-sm-3 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--md">
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">02</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-color--white">Risk management</h3>
                        <p class="g-color--white-opacity">Through identifying, analysing, evaluating, and addressing, the first step of cyber risk management is to carry out a risk assessment. This will give you an overview of the cyber threats you could be facing and enable you to prioritise the severity of the potential impact on your business.</p>
                    </div>
                </div>
            </li>

            <li class="col-sm-3 col-xs-6 g-full-width--xs s-process-v1 g-margin-b-60--xs g-margin-b-0--sm">
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">03</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-color--white">Engagement and training</h3>
                        <p class="g-color--white-opacity">The people in your business can either be your biggest liability or your strongest defence when it comes to the threat of a cyber attack. This all depends on how much they know about and understand cyber security. Supporting your teams with training in the skills and knowledge they need to work securely will dramatically improve your cyber security and highlight to them their importance to the business.</p>
                    </div>
                </div>
            </li>

            <li class="col-sm-3 col-xs-6 g-full-width--xs s-process-v1">
                <div class="center-block g-text-center--xs">
                    <div class="g-margin-b-30--xs">
                        <span class="g-display-inline-block--xs g-width-100--xs g-height-100--xs g-font-size-38--xs g-color--primary g-bg-color--white g-box-shadow__dark-lightest-v4 g-padding-x-20--xs g-padding-y-20--xs g-radius--circle">04</span>
                    </div>
                    <div class="g-padding-x-20--xs">
                        <h3 class="g-font-size-18--xs g-color--white">Architecture and configuration</h3>
                        <p class="g-color--white-opacity">Technology and cyber security are constantly changing. To manage this, businesses need to ensure a strong cyber security ethos is carved into their systems and services from the get-go and maintained to that same standard as new threats emerge.</p>
                    </div>
                </div>
            </li>
        </ul>

        <div class="g-text-center--xs">
            <a href="#" onclick="window.location.href = 'https://cyberconsult.sa/contact_us.php'"
               class="text-uppercase s-btn s-btn--md s-btn--white-bg g-radius--50 g-padding-x-70--xs">Contact Us</a>
        </div>
    </div>
</div>
-->
<!-- End Process -->

<!-- News -->
<!--
<div class="g-bg-color--sky-light">
    <div class="container g-padding-y-80--xs g-padding-y-125--sm">
        <div class="g-text-center--xs g-margin-b-80--xs">
            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-25--xs">Blog</p>
            <h2 class="g-font-size-32--xs g-font-size-36--md g-letter-spacing--1">Latest News</h2>
        </div>
        <div class="row">
            <div class="col-sm-4 g-margin-b-30--xs g-margin-b-0--md">
                <article>
                    <img class="img-responsive" src="img/970x970/01.jpg" alt="Image">
                    <div class="g-bg-color--white g-box-shadow__dark-lightest-v2 g-text-center--xs g-padding-x-40--xs g-padding-y-40--xs">
                        <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2">News</p>
                        <h3 class="g-font-size-22--xs g-letter-spacing--1"><a href="https://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes">Create Something Great.</a></h3>
                        <p>The time has come to bring those ideas and plans to life.</p>
                    </div>
            </div>
            <div class="col-sm-4 g-margin-b-30--xs g-margin-b-0--md">
                <article>
                    <img class="img-responsive" src="img/970x970/02.jpg" alt="Image">
                    <div class="g-bg-color--white g-box-shadow__dark-lightest-v2 g-text-center--xs g-padding-x-40--xs g-padding-y-40--xs">
                        <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2">News</p>
                        <h3 class="g-font-size-22--xs g-letter-spacing--1"><a href="https://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes">Jacks of All. Experts in All.</a></h3>
                        <p>The time has come to bring those ideas and plans to life.</p>
                    </div>
                </article>
            </div>
            <div class="col-sm-4">
                <article>
                    <img class="img-responsive" src="img/970x970/03.jpg" alt="Image">
                    <div class="g-bg-color--white g-box-shadow__dark-lightest-v2 g-text-center--xs g-padding-x-40--xs g-padding-y-40--xs">
                        <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2">News</p>
                        <h3 class="g-font-size-22--xs g-letter-spacing--1"><a href="https://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes">Finding your Perfect Place.</a></h3>
                        <p>The time has come to bring those ideas and plans to life.</p>
                    </div>
                </article>
            </div>
        </div>
    </div>
</div>
-->

<!-- Subscribe -->
<!--
<div class="g-bg-color--dark-light">
    <div class="g-container--sm g-text-center--xs g-padding-y-80--xs g-padding-y-125--sm">
        <div class="g-margin-b-60--xs">
            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--white-opacity g-letter-spacing--2 g-margin-b-25--xs">Subscribe</p>
            <h2 class="g-font-size-32--xs g-font-size-36--sm g-letter-spacing--1 g-color--white">Join Over 1000+ People</h2>
        </div>
        <div class="row">
            <div class="col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                <form class="input-group">
                    <input type="email" class="form-control s-form-v1__input g-radius--left-50" name="email" placeholder="Enter your email">
                    <span class="input-group-btn">
                        <button type="submit" class="s-btn s-btn-icon--md s-btn-icon--white-brd s-btn--white-brd g-radius--right-50"><i class="ti-arrow-right"></i></button>
                    </span>
                </form>
            </div>
        </div>
    </div>
</div>
-->
<!-- End Subscribe -->
<!--========== END PAGE CONTENT ==========-->

<!--========== FOOTER ==========-->
<!--========== FOOTER ==========-->
<footer class="g-bg-color--dark">
    <!-- Links -->
    <div class="g-hor-divider__dashed--white-opacity-lightest">
        <div class="container g-padding-y-80--xs">
            <div class="row">
                <div class="col-sm-2 g-margin-b-20--xs g-margin-b-0--md">
                    <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-0--xs">
                        <!--
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="https://cyberconsult.sa/">Home</a>
                        </li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="https://cyberconsult.sa/about_us.php">About Us</a>
                        </li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="https://cyberconsult.sa/team.php">Team</a>
                        </li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="https://cyberconsult.sa/our_services.php">Our Services</a>
                        </li>
                        -->
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="https://cyberconsult.sa/contact_us.php">Contact Us</a>
                        </li>
                    </ul>
                </div>
                <!--
                <div class="col-sm-2 g-margin-b-20--xs g-margin-b-0--md">
                    <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-0--xs">
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="#">Twitter</a>
                        </li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="#">Facebook</a>
                        </li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="#">Instagram</a>
                        </li>
                    </ul>
                </div>
                -->

                <!--
                <div class="col-sm-2 g-margin-b-40--xs g-margin-b-0--md">
                    <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-0--xs">
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="#">Privacy
                                Policy</a></li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="#">Terms
                                &amp; Conditions</a></li>
                    </ul>
                </div>
                -->
                <div class="col-md-6 col-md-offset-2 col-sm-5 col-sm-offset-1 s-footer__logo g-padding-y-50--xs g-padding-y-0--md">
                    <!-- <h3 class="g-font-size-18--xs g-color--white">cyberconsult.sa</h3> -->
                    <p class="g-color--white-opacity">Cyber Consult provides access to a package of international, local and industry specific standards. We use the specialist tools and modern practices to investigate your information security environment and provide effective solutions.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- End Links -->

    <!-- Copyright -->
    <div class="container g-padding-y-50--xs">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-xs-12">
                <a href="https://cyberconsult.sa/">
                    <img class="g-width-75--xs g-height-auto--xs" src="https://cyberconsult.sa/logo/Cyber Consult small 2.png"
                         alt="cyberconsult.sa">
                </a>
            </div>

            <div class="col-lg-4 col-md-4 col-xs-12 g-text-left--xs">
                <p class="g-font-size-14--xs g-margin-b-0--xs g-color--white">&copy; Copyright <a
                            href="https://cyberconsult.sa/">cyberconsult.sa</a> 2022                    <!-- <a href="http://www.keenthemes.com/">KeenThemes.com</a></p> -->
            </div>

            <div class="col-lg-4 col-md-4 col-xs-12 g-text-left--xs">
                <p class="g-font-size-14--xs g-margin-b-0--xs g-color--white"><a
                            href="https://cyberconsult.sa/">cyberconsult.sa</a> Developed by: <a
                            href="https://me.rezayogaswara.com">Reza Yogaswara</a></p>

            </div>
        </div>
    </div>
    <!-- End Copyright -->
</footer>
<!--========== END FOOTER ==========-->

<!-- Back To Top -->
<a href="javascript:void(0);" class="s-back-to-top js__back-to-top"></a>

<!--========== JAVASCRIPTS (Load javascripts at bottom, this will reduce page load time) ==========-->
<!-- Vendor -->
<script type="text/javascript" src="vendor/jquery.min.js"></script>
<script type="text/javascript" src="vendor/jquery.migrate.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="vendor/jquery.smooth-scroll.min.js"></script>
<script type="text/javascript" src="vendor/jquery.back-to-top.min.js"></script>
<script type="text/javascript" src="vendor/scrollbar/jquery.scrollbar.min.js"></script>
<script type="text/javascript" src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="vendor/jquery.parallax.min.js"></script>
<script type="text/javascript" src="vendor/swiper/swiper.jquery.min.js"></script>
<script type="text/javascript" src="vendor/jquery.wow.min.js"></script>

<!-- General Components and Settings -->
<script type="text/javascript" src="js/global.min.js"></script>
<script type="text/javascript" src="js/components/header-sticky.min.js"></script>
<script type="text/javascript" src="js/components/scrollbar.min.js"></script>
<script type="text/javascript" src="js/components/magnific-popup.min.js"></script>
<script type="text/javascript" src="js/components/swiper.min.js"></script>
<script type="text/javascript" src="js/components/wow.min.js"></script>
<!--========== END JAVASCRIPTS ==========-->

</body>
<!-- End Body -->
</html>
