<!DOCTYPE html>
<html lang="en" class="no-js">
<!-- Begin Head -->
<head>
    <!-- Basic -->
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>cyberconsult.sa - A Digital Security Consultant in Communication and Information Technology</title>
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <meta name="author" content="Reza Yogaswara"/>
    <meta name="website" content="https://me.rezayogaswara.com"/>
    <meta name="version" content="1.0.0"/>
    <meta
            name="description"
            content="A Digital Security Consultant in Communication and Information Technology"
    />
    <meta name="keywords" content="cyberconsult.sa, A Digital Security Consultant in Communication and Information Technology"/>

    <!-- Web Fonts -->
    <!--<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i|Montserrat:400,700" rel="stylesheet">-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@200;300;400;500&display=swap" rel="stylesheet">

    <!-- Vendor Styles -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="css/animate.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/themify/themify.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/scrollbar/scrollbar.min.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/swiper/swiper.min.css" rel="stylesheet" type="text/css"/>
    <link href="vendor/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet" type="text/css"/>

    <!-- Theme Styles -->
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
    <link href="css/global/global.css" rel="stylesheet" type="text/css"/>

    <!-- Favicon -->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="img/apple-touch-icon.png">
</head>
<!-- End Head -->

<!-- Body -->
<body>

<!--========== HEADER ==========-->
<header class="navbar-fixed-top s-header js__header-sticky js__header-overlay">
    <!-- Navbar -->
    <div class="s-header__navbar">
        <div class="s-header__container">
            <div class="s-header__navbar-row">
                <div class="s-header__navbar-row-col">
                    <!-- Logo -->
                    <div class="s-header__logo">
                        <a href="https://cyberconsult.sa/" class="s-header__logo-link">
                            <!--
                            <img class="s-header__logo-img s-header__logo-img-default" src="img/logo.png" alt="cyberconsult.sa">
                            <img class="s-header__logo-img s-header__logo-img-shrink" src="img/logo-dark.png" alt="cyberconsult.sa">
                            -->
                            <img class="s-header__logo-img s-header__logo-img-default"
                                 src="https://cyberconsult.sa/logo/Cyber Consult small 2.png" alt="cyberconsult.sa">
                            <img class="s-header__logo-img s-header__logo-img-shrink"
                                 src="https://cyberconsult.sa/logo/Cyber Consult small 2.png" alt="cyberconsult.sa">
                        </a>
                    </div>
                    <!-- End Logo -->
                </div>
                <div class="s-header__navbar-row-col">
                    <!-- Trigger -->
                    <a href="javascript:void(0);" class="s-header__trigger js__trigger">
                        <span class="s-header__trigger-icon"></span>
                        <svg x="0rem" y="0rem" width="3.125rem" height="3.125rem" viewbox="0 0 54 54">
                            <circle fill="transparent" stroke="#fff" stroke-width="1" cx="27" cy="27" r="25"
                                    stroke-dasharray="157 157" stroke-dashoffset="157"></circle>
                        </svg>
                    </a>
                    <!-- End Trigger -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Navbar -->

    <!-- Overlay -->
    <div class="s-header-bg-overlay js__bg-overlay">
        <!-- Nav -->
        <nav class="s-header__nav js__scrollbar">
            <div class="container-fluid">
                <!-- Menu List -->
                <!--
                <ul class="list-unstyled s-header__nav-menu">
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider -is-active" href="index.html">Corporate</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_app_landing.html">App Landing</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_portfolio.html">Portfolio</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_events.html">Events</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_lawyer.html">Lawyer</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_clinic.html">Clinic</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="index_coming_soon.html">Coming Soon</a></li>
                </ul>
                -->
                <!-- End Menu List -->

                <!-- Menu List -->
                <ul class="list-unstyled s-header__nav-menu">
                    <li class="s-header__nav-menu-item"><a
                                class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="https://cyberconsult.sa/">Home</a>
                    </li>
                    <li class="s-header__nav-menu-item"><a
                                class="s-header__nav-menu-link s-header__nav-menu-link-divider"
                                href="https://cyberconsult.sa/about_us.php">About
                            Us</a></li>
                    <li class="s-header__nav-menu-item"><a
                                class="s-header__nav-menu-link s-header__nav-menu-link-divider"
                                href="https://cyberconsult.sa/team.php">Team</a></li>
                    <li class="s-header__nav-menu-item"><a
                                class="s-header__nav-menu-link s-header__nav-menu-link-divider -is-active"
                                href="https://cyberconsult.sa/our_services.php">Our
                            Services</a></li>
                    <!--<li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="events.html">Events</a></li>
                    <li class="s-header__nav-menu-item"><a class="s-header__nav-menu-link s-header__nav-menu-link-divider" href="faq.html">FAQ</a></li>-->
                    <li class="s-header__nav-menu-item"><a
                                class="s-header__nav-menu-link s-header__nav-menu-link-divider"
                                href="https://cyberconsult.sa/contact_us.php">Contact Us</a>
                    </li>
                </ul>
                <!-- End Menu List -->
            </div>
        </nav>
        <!-- End Nav -->

        <!-- Action -->
        <!--
        <ul class="list-inline s-header__action s-header__action--lb">
            <li class="s-header__action-item"><a
                        class="s-header__action-link  "
                        href="https://cyberconsult.sa/change_language.php?s=42f5a3a0ff2feb5896eef5a9e82f059c2b4030749878fdcd30ad84d5afbaba4a0e83478552a6c16549204d37dcd48217c90caff1159466f93b53348442a33823&l=aa85f1840e282d8a8304dbc2c0d7c9b2&p=RDVDc0VyQjFDOHAwMzFaRlc0WENYb0JrTnAzbnVsakxRRVJpaWtSZ1BXYz0=">En</a>
            </li>
            <li class="s-header__action-item"><a
                        class="s-header__action-link "
                        href="https://cyberconsult.sa/change_language.php?s=42f5a3a0ff2feb5896eef5a9e82f059c2b4030749878fdcd30ad84d5afbaba4a0e83478552a6c16549204d37dcd48217c90caff1159466f93b53348442a33823&l=3dd6b9265ff18f31dc30df59304b0ca7&p=RDVDc0VyQjFDOHAwMzFaRlc0WENYb0JrTnAzbnVsakxRRVJpaWtSZ1BXYz0=">Ar</a>
            </li>
        </ul>
        -->
        <!-- End Action -->

        <!-- Action -->
        <!--
        <ul class="list-inline s-header__action s-header__action--rb">
            <li class="s-header__action-item">
                <a class="s-header__action-link" href="#">
                    <i class="g-padding-r-5--xs ti-twitter"></i>
                    <span class="g-display-none--xs g-display-inline-block--sm">Twitter</span>
                </a>
            </li>
            <li class="s-header__action-item">
                <a class="s-header__action-link" href="#">
                    <i class="g-padding-r-5--xs ti-facebook"></i>
                    <span class="g-display-none--xs g-display-inline-block--sm">Facebook</span>
                </a>
            </li>
            <li class="s-header__action-item">
                <a class="s-header__action-link" href="#">
                    <i class="g-padding-r-5--xs ti-instagram"></i>
                    <span class="g-display-none--xs g-display-inline-block--sm">Instagram</span>
                </a>
            </li>
        </ul>
        -->
        <!-- End Action -->
    </div>
    <!-- End Overlay -->
</header>
<!--========== END HEADER ==========-->

<!--========== PROMO BLOCK ==========-->
<section class="s-video-v2__bg"
         data-vidbg-bg="mp4: include/media/mp4_video.mp4, webm: include/media/webm_video.webm, poster: include/media/fallback.jpg"
         data-vidbg-options="loop: true, muted: true, overlay: false">
    <div class="container g-position--overlay g-text-center--xs">
        <div class="g-padding-y-50--xs g-margin-t-100--xs g-margin-b-100--xs g-margin-b-250--md">
            <h2 class="g-font-size-30--xs g-font-size-40--sm g-font-size-50--md g-color--white">The path to cyber resilience</h2>
        </div>
    </div>
</section>
<!--========== END PROMO BLOCK ==========-->

<!--========== PAGE CONTENT ==========-->
<!-- Mockup -->
<!--
<div class="container g-margin-t-o-150--xs">
    <div class="center-block s-mockup-v1">
        <img class="img-responsive" src="img/mockups/devices-01.png" alt="Mockup Image">
    </div>
</div>
-->
<!-- End Mockup -->

<!-- Plan -->
<div class="g-bg-color--sky-light">
    <div class="container g-padding-y-80--xs g-padding-y-125--xsm">
        <!--
        <div class="g-text-center--xs g-margin-b-80--xs">
            <p class="text-uppercase g-font-size-14--xs g-font-weight--700 g-color--primary g-letter-spacing--2 g-margin-b-25--xs">
                Plan</p>
            <h2 class="g-font-size-32--xs g-font-size-36--md">Finding your Plan</h2>
        </div>
        -->

        <div class="row g-row-col--5">
                                <!-- Plan -->

                    
                    <div class="col-md-4 g-margin-b-10--xs g-margin-b-0--lg">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".1s">
                            <div class="s-plan-v1 g-text-center--xs g-bg-color--white g-padding-y-100--xs">
                                <i class="g-display-block--xs g-font-size-40--xs g-color--primary g-margin-b-30--xs ti-archive"></i>
                                <h3 class="g-font-size-18--xs g-color--primary g-margin-b-30--xs">Custom Consultancy</h3>
                                <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-40-- " style="padding: 10px;">
                                    <li><i class="g-font-size-13--xs g-color--primary g-margin-r-10--xs ti-check"></i>
                                        The world has never been more compliant or regulated. People want to know that their personal details and banking information are safe with you. Therefore, organizations interested in getting certifications will require some assistance and this is where we step in.  We offer access to skilled experts to ensure your necessities are met. We also provide advice and help with new technologies, products and services. We offer access to vulnerability scans, multiple data protection training programs and information security training. 
                                    </li>
                                </ul>
                                <!--
                                <div class="g-margin-b-40--xs">
                                    <span class="s-plan-v1__price-tag"></span>
                                </div>
                                -->
                                <button type="button" onclick="window.location.href = 'https://cyberconsult.sa/contact_us.php'"
                                        class="text-uppercase s-btn s-btn--sm s-btn--primary-bg g-radius--50 g-padding-x-50--xs">
                                    Contact Us
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- End Plan -->
                                    <!-- Plan -->

                    
                    <div class="col-md-4 g-margin-b-10--xs g-margin-b-0--lg">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".1s">
                            <div class="s-plan-v1 g-text-center--xs g-bg-color--white g-padding-y-100--xs">
                                <i class="g-display-block--xs g-font-size-40--xs g-color--primary g-margin-b-30--xs ti-archive"></i>
                                <h3 class="g-font-size-18--xs g-color--primary g-margin-b-30--xs">Exclusive Audit</h3>
                                <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-40-- " style="padding: 10px;">
                                    <li><i class="g-font-size-13--xs g-color--primary g-margin-r-10--xs ti-check"></i>
                                        The exclusive audit from Cyber Consult is a more detailed investigation into your organization and information security. It also targets topics like data protection. This audit is more useful to organizations seeking different certifications. The service is based on evidence regarding policies, systems and procedures. Such an audit is also a helpful tool in providing evidence for further accreditation and certifications. We will report whatever we can find with a risk score and provide ideas regarding what you can do to improve this score. A strategic solution can also be implemented into our report should you require it.                                     </li>
                                </ul>
                                <!--
                                <div class="g-margin-b-40--xs">
                                    <span class="s-plan-v1__price-tag"></span>
                                </div>
                                -->
                                <button type="button" onclick="window.location.href = 'https://cyberconsult.sa/contact_us.php'"
                                        class="text-uppercase s-btn s-btn--sm s-btn--primary-bg g-radius--50 g-padding-x-50--xs">
                                    Contact Us
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- End Plan -->
                                    <!-- Plan -->

                    
                    <div class="col-md-4 g-margin-b-10--xs g-margin-b-0--lg">
                        <div class="wow fadeInUp" data-wow-duration=".3" data-wow-delay=".1s">
                            <div class="s-plan-v1 g-text-center--xs g-bg-color--white g-padding-y-100--xs">
                                <i class="g-display-block--xs g-font-size-40--xs g-color--primary g-margin-b-30--xs ti-archive"></i>
                                <h3 class="g-font-size-18--xs g-color--primary g-margin-b-30--xs">High Quality Assessment</h3>
                                <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-40-- " style="padding: 10px;">
                                    <li><i class="g-font-size-13--xs g-color--primary g-margin-r-10--xs ti-check"></i>
                                        Cyber Consultant offers a high-level assessment of the potential risks associated with your organization – fully independent. The process may also imply discussing with key people who have relevant information in your company. The high-level assessment may reveal areas of concern, which will be outlined in our report. Such assessments are handy for managerial and technical staff to become familiar with the environment and associated risks. The report may underline the necessity of immediate action, but you may also find that you are doing an excellent job.
                                    </li>
                                </ul>
                                <!--
                                <div class="g-margin-b-40--xs">
                                    <span class="s-plan-v1__price-tag"></span>
                                </div>
                                -->
                                <button type="button" onclick="window.location.href = 'https://cyberconsult.sa/contact_us.php'"
                                        class="text-uppercase s-btn s-btn--sm s-btn--primary-bg g-radius--50 g-padding-x-50--xs">
                                    Contact Us
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- End Plan -->
                            
        </div>
    </div>
</div>
<!-- End Plan -->

<!--========== END PAGE CONTENT ==========-->

<!--========== FOOTER ==========-->
<footer class="g-bg-color--dark">
    <!-- Links -->
    <div class="g-hor-divider__dashed--white-opacity-lightest">
        <div class="container g-padding-y-80--xs">
            <div class="row">
                <div class="col-sm-2 g-margin-b-20--xs g-margin-b-0--md">
                    <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-0--xs">
                        <!--
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="https://cyberconsult.sa/">Home</a>
                        </li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="https://cyberconsult.sa/about_us.php">About Us</a>
                        </li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="https://cyberconsult.sa/team.php">Team</a>
                        </li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="https://cyberconsult.sa/our_services.php">Our Services</a>
                        </li>
                        -->
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="https://cyberconsult.sa/contact_us.php">Contact Us</a>
                        </li>
                    </ul>
                </div>
                <!--
                <div class="col-sm-2 g-margin-b-20--xs g-margin-b-0--md">
                    <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-0--xs">
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="#">Twitter</a>
                        </li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="#">Facebook</a>
                        </li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="#">Instagram</a>
                        </li>
                    </ul>
                </div>
                -->

                <!--
                <div class="col-sm-2 g-margin-b-40--xs g-margin-b-0--md">
                    <ul class="list-unstyled g-ul-li-tb-5--xs g-margin-b-0--xs">
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="#">Privacy
                                Policy</a></li>
                        <li><a class="g-font-size-15--xs g-color--white-opacity"
                               href="#">Terms
                                &amp; Conditions</a></li>
                    </ul>
                </div>
                -->
                <div class="col-md-6 col-md-offset-2 col-sm-5 col-sm-offset-1 s-footer__logo g-padding-y-50--xs g-padding-y-0--md">
                    <!--<h3 class="g-font-size-18--xs g-color--white">cyberconsult.sa</h3> -->
                    <p class="g-color--white-opacity">Cyber Consult provides access to a package of international, local and industry specific standards. We use the specialist tools and modern practices to investigate your information security environment and provide effective solutions.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- End Links -->

    <!-- Copyright -->
    <div class="container g-padding-y-50--xs">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-xs-12">
                <a href="https://cyberconsult.sa/">
                    <img class="g-width-75--xs g-height-auto--xs" src="https://cyberconsult.sa/logo/Cyber Consult small 2.png"
                         alt="cyberconsult.sa">
                </a>
            </div>

            <div class="col-lg-4 col-md-4 col-xs-12 g-text-left--xs">
                <p class="g-font-size-14--xs g-margin-b-0--xs g-color--white">&copy; Copyright <a
                            href="https://cyberconsult.sa/">cyberconsult.sa</a> 2022                    <!-- <a href="http://www.keenthemes.com/">KeenThemes.com</a></p> -->
            </div>

            <div class="col-lg-4 col-md-4 col-xs-12 g-text-left--xs">
                <p class="g-font-size-14--xs g-margin-b-0--xs g-color--white"><a
                            href="https://cyberconsult.sa/">cyberconsult.sa</a> Developed by: <a
                            href="https://me.rezayogaswara.com">Reza Yogaswara</a></p>

            </div>
        </div>
    </div>
    <!-- End Copyright -->
</footer>
<!--========== END FOOTER ==========-->

<!-- Back To Top -->
<a href="javascript:void(0);" class="s-back-to-top js__back-to-top"></a>

<!--========== JAVASCRIPTS (Load javascripts at bottom, this will reduce page load time) ==========-->
<!-- Vendor -->
<script type="text/javascript" src="vendor/jquery.min.js"></script>
<script type="text/javascript" src="vendor/jquery.migrate.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="vendor/jquery.smooth-scroll.min.js"></script>
<script type="text/javascript" src="vendor/jquery.back-to-top.min.js"></script>
<script type="text/javascript" src="vendor/scrollbar/jquery.scrollbar.min.js"></script>
<script type="text/javascript" src="vendor/vidbg.min.js"></script>
<script type="text/javascript" src="vendor/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
<script type="text/javascript" src="vendor/waypoint.min.js"></script>
<script type="text/javascript" src="vendor/counterup.min.js"></script>
<script type="text/javascript" src="vendor/swiper/swiper.jquery.min.js"></script>
<script type="text/javascript" src="vendor/jquery.wow.min.js"></script>

<!-- General Components and Settings -->
<script type="text/javascript" src="js/global.min.js"></script>
<script type="text/javascript" src="js/components/header-sticky.min.js"></script>
<script type="text/javascript" src="js/components/scrollbar.min.js"></script>
<script type="text/javascript" src="js/components/portfolio-4-col-slider.min.js"></script>
<script type="text/javascript" src="js/components/counter.min.js"></script>
<script type="text/javascript" src="js/components/swiper.min.js"></script>
<script type="text/javascript" src="js/components/wow.min.js"></script>
<!--========== END JAVASCRIPTS ==========-->

</body>
<!-- End Body -->
</html>
